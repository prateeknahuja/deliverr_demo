// Import modules
const express= require('express');
const CryptoJS = require("crypto-js");
const mongoose = require("mongoose");
const bodyParser = require('body-parser');
const Message=  require('./models/msg_model');

//Initialize variables
const app = express();
const port = process.env.PORT || 3000;
const dbConnection =  "mongodb+srv://deliverr-db-user:tempPassword1@cluster1.txfob.mongodb.net/deliverrdb?retryWrites=true&w=majority"   //Mongo DB database hosted on MongoDb Atlas
const key = "1515242426161525";  // Secret key used to encrypt the message
var encryptedMessage;
var jsonParser = bodyParser.json()
// ------------------------------------------------------------------------------------------------------------------------------------------

//Mongodb Connection 
// ==========================================================================
mongoose.connect(dbConnection, {
    useNewUrlParser: true, 
    useUnifiedTopology: true
});

mongoose.connection.on("error", err => {
    console.log("MongoDb Error: ", err)
  });

  mongoose.connection.on("connected", (err, res) => {
    console.log("Connected to mongodb database")
  });
// =============================================================================

//Start the service on port 3000
app.listen(port, ()=>{
    console.log("Started the app on port "+ port);
});

app.get('/health', (req,res)=> {
    res.send("Message Microservice is running."); 
});


// API to encrypt the message and store it in the mongodb database
app.post('/storeMessage', jsonParser, (req,res)=> {
    
    // Encrypt
    encryptedMessage = CryptoJS.AES.encrypt(req.body.message, key).toString();

    //Create an object of Message model
    var newMessage =  new Message({
        secretMessage: encryptedMessage
    });
    
    // Save the new encrypted message in the messages collection 
    newMessage.save().then((result) =>{
        res.send(result);
    }).catch((err)=>{
        console.log(err);
    });
});


// API to retrieve the message from the mongodb
app.get('/getMessage', (req,res)=> {
    var msg =  new Message();
    
    //Retrieve the last message from messages collection.
    Message.find().sort({$natural:-1}).limit(1).then((result)=>{
        // Decrypt the message. 
        var bytes  = CryptoJS.AES.decrypt(result[0].secretMessage, key);
        var message = bytes.toString(CryptoJS.enc.Utf8);
        res.send(message);
    }).catch((err)=>{
        console.log(err);
    }); 
});