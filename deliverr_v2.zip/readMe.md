The Message Microservices is responsible for storing and retreving a sensitive message. 

The microservice has three apis:

- GET /health => To check if the microservice is up and running.

- POST /storeMessage => This api needs the message to be passed in the body of the request. 
                        This message is then encrypted and stored in the messages database 

                        ex. body 
                        {
                            "message": "This is the secret message"
                        }

- GET /getMessage => This api retrieves the last message stored in the database. 
                     Decrypts the message using the same key and returns the message to the user. 